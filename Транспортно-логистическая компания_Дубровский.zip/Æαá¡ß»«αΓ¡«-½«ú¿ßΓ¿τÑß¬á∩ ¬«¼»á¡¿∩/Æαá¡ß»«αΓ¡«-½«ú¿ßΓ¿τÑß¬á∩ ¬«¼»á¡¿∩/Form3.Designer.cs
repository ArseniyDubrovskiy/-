﻿namespace Транспортно_логистическая_компания
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Menu = new System.Windows.Forms.Label();
            this.spisok = new System.Windows.Forms.Button();
            this.sotrudniki = new System.Windows.Forms.Button();
            this.Jalobi = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.AutoSize = true;
            this.Menu.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Menu.Location = new System.Drawing.Point(311, 66);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(133, 50);
            this.Menu.TabIndex = 0;
            this.Menu.Text = "Меню";
            this.Menu.Click += new System.EventHandler(this.label1_Click);
            // 
            // spisok
            // 
            this.spisok.Location = new System.Drawing.Point(302, 200);
            this.spisok.Name = "spisok";
            this.spisok.Size = new System.Drawing.Size(152, 51);
            this.spisok.TabIndex = 1;
            this.spisok.Text = "Список заказов";
            this.spisok.UseVisualStyleBackColor = true;
            this.spisok.Click += new System.EventHandler(this.spisok_Click);
            // 
            // sotrudniki
            // 
            this.sotrudniki.Location = new System.Drawing.Point(302, 314);
            this.sotrudniki.Name = "sotrudniki";
            this.sotrudniki.Size = new System.Drawing.Size(152, 51);
            this.sotrudniki.TabIndex = 2;
            this.sotrudniki.Text = "Сотрудники";
            this.sotrudniki.UseVisualStyleBackColor = true;
            this.sotrudniki.Click += new System.EventHandler(this.sotrudniki_Click);
            // 
            // Jalobi
            // 
            this.Jalobi.Location = new System.Drawing.Point(302, 257);
            this.Jalobi.Name = "Jalobi";
            this.Jalobi.Size = new System.Drawing.Size(152, 51);
            this.Jalobi.TabIndex = 3;
            this.Jalobi.Text = "Жалобы";
            this.Jalobi.UseVisualStyleBackColor = true;
            this.Jalobi.Click += new System.EventHandler(this.Jalobi_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 38);
            this.button1.TabIndex = 4;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Транспортно_логистическая_компания.Properties.Resources._4ce90cfa_1bd4_4654_a8de_61bc54dc;
            this.pictureBox1.Location = new System.Drawing.Point(540, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 61);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Jalobi);
            this.Controls.Add(this.sotrudniki);
            this.Controls.Add(this.spisok);
            this.Controls.Add(this.Menu);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Menu;
        private Button spisok;
        private Button sotrudniki;
        private Button Jalobi;
        private Button button1;
        private PictureBox pictureBox1;
    }
}