namespace Транспортно_логистическая_компания
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 Register = new Form2();
            Register.ShowDialog();
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
 
            string log1 = textBox1.Text;
            string parol2 = textBox2.Text;
            if (textBox1.Text == "" || textBox2.Text == "")
            {

                MessageBox.Show("Неверный логин или пароль!", "Ошибка!");

            }
            else if (log1.Length > 45 || parol2.Length > 35)
            {

                MessageBox.Show("Неверный логин или пароль!", "Ошибка!");

            }
            else
            {
                this.Hide();
                Form3 form3 = new Form3();
                form3.Show();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            Form2 Register = new Form2();
            Register.ShowDialog();
            
        }
    }
}