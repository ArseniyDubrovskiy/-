﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Транспортно_логистическая_компания
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void spisok_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 zakazi = new Form4();
            zakazi.ShowDialog();
            this.Close();
        }

        private void Jalobi_Click(object sender, EventArgs e)
        {
            this.Hide();
            Жалобы jalobi = new Жалобы();
            jalobi.ShowDialog();
            
        }

        private void sotrudniki_Click(object sender, EventArgs e)
        {
            this.Hide();
            Сотрудники sotrudniki = new Сотрудники();
            sotrudniki.ShowDialog();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
