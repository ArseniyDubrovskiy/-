﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Транспортно_логистическая_компания
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login = new Form1();
            Login.ShowDialog();
            
        }

        private void Regi_Click(object sender, EventArgs e)
        {
            string parol = textBox4.Text;
            string log = textBox3.Text;
            string email = textBox5.Text;
            if (textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка!");
                
            }
            else if (log.Length > 45 || parol.Length > 35 || email.Length > 100)
            {
                
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка!");
                
            }
        
             
}

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
            
        }

        private void Regi_Click_1(object sender, EventArgs e)
        {
            string parol = textBox4.Text;
            string log = textBox3.Text;
            string email = textBox5.Text;
            if (textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {

                MessageBox.Show( "Ошибка!");

            }
            else if (log.Length > 45 || parol.Length > 35 || email.Length > 100)
            {

                MessageBox.Show( "Ошибка!");

            }
            else
            {
                this.Hide();
                Form1 form1 = new Form1();
                form1.ShowDialog();
                
            }
        }

        private void vihod_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }
    }
    }

